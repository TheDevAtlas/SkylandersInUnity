using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PortalController : MonoBehaviour
{
    public Portal portal;
    Figure fig = new Figure();

    [Header("UI Elements")]
    public Image image;
    public Sprite[] sprites;
    public Color[] elementColors;

    public TextMeshProUGUI skyName;

    [Header("Skylander Information")]
    public int element;
    public JSONReader jsonReader;
    // public bool isSwap;

    void Start(){
        portal = Portal.Instance;
        portal.Ready();
        portal.Activate();

        // READ SLYLANDER FROM PORTAL OF POWER //
        // ReadSkylander();
    }

    void Update(){
        // UPDATE THE UI AND THE PORTAL BASED ON THE CURRENT SKYLANDER //
        image.sprite = sprites[element];
        UpdatePortalColor();
    }

    void UpdatePortalColor(){
        byte r = (byte)(elementColors[element].r * 255f);
        byte g = (byte)(elementColors[element].g * 255f);
        byte b = (byte)(elementColors[element].b * 255f);
        portal.SetColor(r,g,b);
    }

    public void ReadSkylander(){
        StatusResult result = portal.GetStatus();
        fig = new Figure();
        if(result.characterIndexes.Count == 1){
            fig.ReadData(result.characterIndexes[0]);

            // READ FROM JSON FILE AND SEARCH IT BASED ON FIG.ID //
            for(int i = 0; i < 586; i++){
                //print(jsonReader.skylanderList.skylanders[i].Name);
                if(jsonReader.skylanderList.skylanders[i].Id == fig.ID){
                    skyName.text = jsonReader.skylanderList.skylanders[i].Name;
                    element = ConvertElement(jsonReader.skylanderList.skylanders[i].Element);
                    break;
                }
            }
        }

        if(result.characterIndexes.Count == 2){
            Figure[] swapFig = {new Figure(), new Figure()};
            swapFig[0].ReadData(result.characterIndexes[0]);
            swapFig[1].ReadData(result.characterIndexes[1]);

            // READ FROM JSON FILE AND SEARCH IT BASED ON FIG.ID //
            for(int i = 0; i < 586; i++){
                //print(jsonReader.skylanderList.skylanders[i].Name);
                if(jsonReader.skylanderList.skylanders[i].Id == swapFig[1].ID){
                    skyName.text = jsonReader.skylanderList.skylanders[i].Name;
                    element = ConvertElement(jsonReader.skylanderList.skylanders[i].Element);
                    break;
                }
            }
            // SECOND FIGURE
            for(int i = 0; i < 586; i++){
                //print(jsonReader.skylanderList.skylanders[i].Name);
                if(jsonReader.skylanderList.skylanders[i].Id == swapFig[0].ID){
                    skyName.text += jsonReader.skylanderList.skylanders[i].Name;
                    element = ConvertElement(jsonReader.skylanderList.skylanders[i].Element);
                    break;
                }
            }
        }
    }

    int ConvertElement(string rawElement){
        // RETUNRN THE ELEMENT IN SKYLANDERS IMAGIONATORS ORDER //
        if(rawElement == "Light"){
            return 0;
        }
        if(rawElement == "Air"){
            return 1;
        }
        if(rawElement == "Life"){
            return 2;
        }
        if(rawElement == "Undead"){
            return 3;
        }
        if(rawElement == "Earth"){
            return 4;
        }
        if(rawElement == "Fire"){
            return 5;
        }
        if(rawElement == "Water"){
            return 6;
        }
        if(rawElement == "Magic"){
            return 7;
        }
        if(rawElement == "Tech"){
            return 8;
        }
        if(rawElement == "Dark"){
            return 9;
        }
        if(rawElement == "Kaos"){
            return 10;
        }
        // NO ELEMENT //
        return 11;
    }
}
