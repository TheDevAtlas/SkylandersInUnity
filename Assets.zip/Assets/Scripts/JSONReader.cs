using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JSONReader : MonoBehaviour
{
    public TextAsset textJSON;

    [System.Serializable]
    public class Skylander
    {
        public int Id;
        public int Variant;
        public string Name;
        public string Series;
        public string Element;
    }

    [System.Serializable]
    public class SkylanderList
    {
        public Skylander[] skylanders;
    }

    public SkylanderList skylanderList = new SkylanderList();

    void Start(){
        skylanderList = JsonUtility.FromJson<SkylanderList>(textJSON.text);
    }
}
